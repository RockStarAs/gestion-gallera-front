export const URL = "http://gallisoft.oo/"

export const STATUS_OK = 200;
export const STATUS_CREATED = 201;

//parametros
export const FLAG_SEXOS = 1;
export const FLAG_TIPOS_AVE = 2;

export const TIPO_MACHO = 1;
export const TIPO_HEMBRA = 2;

export const URL_SIN_FOTO = URL + "storage/gallos/sinfoto.jpg";